1. The TestApp dir include test application.
2. The TestAppCode dir include code of test application.
3. The usb_relay_dll dir include the dll and .h file 
4. The xcgui dir include the GUI library that used by TestApp with GUI.